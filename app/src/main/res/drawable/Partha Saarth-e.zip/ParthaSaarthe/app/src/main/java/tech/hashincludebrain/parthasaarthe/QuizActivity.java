package tech.hashincludebrain.parthasaarthe;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Created by Priyabrata Naskar on 25-01-2021.
 */
public class QuizActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
    }
}